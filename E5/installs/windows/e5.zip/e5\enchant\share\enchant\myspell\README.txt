
This directory contains dictionaries for the myspell backend to enchant.

